import FilterReportIPsByCount
import sys

FilterReportIPsByCount.main(sys.argv[1:])
