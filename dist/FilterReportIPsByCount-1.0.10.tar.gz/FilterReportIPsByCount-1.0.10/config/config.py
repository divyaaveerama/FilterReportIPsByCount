# .gitignore should include reference to config.py

def api_key():
    api_key = "c59c8a2ac5998fce2a6d259cc431bb31b5485fef"
    return api_key
